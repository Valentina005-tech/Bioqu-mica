const materias = [
  { id: "intro", nombre: "Introducción a las Ciencias Químicas", año: 1, requisitos: [] },
  { id: "fisica1", nombre: "Física 1", año: 1, requisitos: ["intro"] },
  { id: "quimica1", nombre: "Química General 1", año: 1, requisitos: ["intro"] },
  { id: "mate1", nombre: "Matemática 1", año: 1, requisitos: ["intro"] },
  { id: "lab1", nombre: "Laboratorio 1", año: 1, requisitos: ["fisica1", "quimica1", "intro"] },
  { id: "fisica2", nombre: "Física 2", año: 1, requisitos: ["fisica1"] },
  { id: "quimica2", nombre: "Química General 2", año: 1, requisitos: ["quimica1"] },
  { id: "mate2", nombre: "Matemática 2", año: 1, requisitos: ["mate1"] },
  { id: "lab2", nombre: "Laboratorio 2", año: 1, requisitos: ["lab1", "quimica2", "fisica2"] },
];

let estado = JSON.parse(localStorage.getItem("progresoMalla")) || {};

function guardarEstado() {
  localStorage.setItem("progresoMalla", JSON.stringify(estado));
}

function esDesbloqueada(materia) {
  return materia.requisitos.every(req => estado[req]);
}

function crearMateria(materia) {
  const div = document.createElement("div");
  div.className = "materia";
  div.textContent = materia.nombre;

  const aprobada = estado[materia.id];
  const desbloqueada = esDesbloqueada(materia);

  if (aprobada) div.classList.add("aprobada");
  else if (!desbloqueada) div.classList.add("bloqueada");

  div.onclick = () => {
    if (!desbloqueada) return;
    estado[materia.id] = !estado[materia.id];
    guardarEstado();
    render();
  };

  return div;
}

function render() {
  const malla = document.getElementById("malla");
  malla.innerHTML = "";

  for (let año = 1; año <= 5; año++) {
    const col = document.createElement("div");
    col.className = "año";
    col.innerHTML = `<h2>${año}° Año</h2>`;
    materias.filter(m => m.año === año).forEach(m => col.appendChild(crearMateria(m)));
    malla.appendChild(col);
  }
}

function resetProgress() {
  if (confirm("¿Estás seguro de reiniciar tu progreso?")) {
    estado = {};
    guardarEstado();
    render();
  }
}

render();
